<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8"
    <title> Welcome to Page Three of Brian Shukwit CSIS 410 Homework Assignment 1</title>

    <link rel="stylesheet" href="style.css">

</head>
<body>
            <div>
				<ul class="navigation">
					
					<li class="home"><a href="/index.php">Home (Page 1) </a></li>
					<li class="page"><a href="/page2.php">Page 2</a></li>
					<li class="page"><a href="/page3.php">Page 3</a></li>					
				</ul>
			</div>
<h1> PHP Print </h1>

<?php 
print "<b>Advantage</b>
There are many advantages to the web host that I chose. The first advantage is that it free for me, because it belongs to my brother-in-law, who is a programmer. Another advantage would be that it has really good personal tech support. I have been currently using github io for a free web host for other web development classes, but they do not support PHP, so I needed a host that did. The last advantage would be that I had to learn more in order to get it to in working order. The major thing I learned about was SCP. 
<br>
<b>Disadvantage</b>
One of the disadvantages of the web host that I chose is that it could crash at any time and would leave my work and assignments inaccessible. My brother-in-law would have to fix it for me. Even though he is very reliable, he is only one person.";
?>
<br>
</body>
     <!-- FOOTER -->
     <footer id="footer" data-stellar-background-ratio="0.5">
          <div class="container">
            <?php
            echo "Last modified: " . date ("F d Y H:i:s.", getlastmod());
            ?>
          </div>
     </footer>
</html>