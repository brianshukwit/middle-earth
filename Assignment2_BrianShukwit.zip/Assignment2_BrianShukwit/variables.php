<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8"
    <title> Brian Shukwit CSIS 410 Homework Assignment 2</title>
</head>
<body>
<h2> Family Tree </h2>
<div class="tree">
	<ul>
		<li>
			<a href="http://brianshukwit.shawnmcginty.com/parents.php">My Parents</a>
			<ul>
				<li><a href="http://brianshukwit.shawnmcginty.com/brian.php">Brian (Me)</a></li>
                <li><a href='http://brianshukwit.shawnmcginty.com/grace.php'>Grace</a></li>
					<ul>
						<li><a href="http://brianshukwit.shawnmcginty.com/emery.php">Emery</a></li>
                        <li><a href="http://brianshukwit.shawnmcginty.com/charlie.php">Charlie</a></li>
						<li><a href="http://brianshukwit.shawnmcginty.com/solomon.php">Solomon</a></li>
						<li><a href="http://brianshukwit.shawnmcginty.com/wolf.php">Wolf</a></li>
					</ul>				
			</ul>
		</li>
	</ul>
</div>
            </body>
     <!-- FOOTER -->
     <footer id="footer" data-stellar-background-ratio="0.5">
          <div class="container">
            <?php
            echo "Last modified: " . date ("F d Y H:i:s.", getlastmod());
            ?>
          </div>
          <p>
      <a href="https://validator.w3.org/check?uri=referer"><img
          src="http://www.w3.org/Icons/valid-xhtml10"
          alt="Valid XHTML 1.0!" height="31" width="88" /></a>
    </p>
     </footer>

</html>